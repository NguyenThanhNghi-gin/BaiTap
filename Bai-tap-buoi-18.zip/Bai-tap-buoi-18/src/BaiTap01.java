public class BaiTap01 {
    public static void main(String[] args) {
        String s = "Cybersoft";
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);

            if (ch != 'a' && ch != 'e' && ch != 'i' && ch !='y' && ch!= 'o' && ch != 'u'
                    && ch != 'A' && ch != 'E' && ch != 'I' && ch !='Y' && ch != 'O' && ch != 'U') {
                System.out.print(ch);
            }
        }
    }
}
