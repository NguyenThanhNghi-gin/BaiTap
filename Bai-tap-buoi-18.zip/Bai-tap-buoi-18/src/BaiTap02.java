import java.util.Scanner;

public class BaiTap02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập số phẩn tử của mảng: ");
        int n  = sc.nextInt();

        if (n < 2) {
            System.out.println(Integer.MIN_VALUE);
            return;
        }

        int[] arr  = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Nhập phần tử thứ " + i + ": ");
            arr[i] = sc.nextInt();
        }

        int max = Integer.MIN_VALUE;
        int secondMax = Integer.MIN_VALUE;

        for (int i = 0; i < n; i++) {
            if (arr[i] > max) {
                secondMax = max;
                max = arr[i];
            } else if (arr[i] < max && arr[i] > secondMax) {
                secondMax = arr[i];
            }
        }

        if (secondMax == Integer.MIN_VALUE) {
            System.out.println(Integer.MIN_VALUE);
        } else {
            System.out.println("Giá trị lớn thứ hai là: " + secondMax);
        }

    }
}
