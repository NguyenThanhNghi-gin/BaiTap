import java.util.Scanner;

public class BaiTap05
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập chuỗi ");
        String str = sc.nextLine();

        String [] words = str.split(" ");


        for (int i = 0; i < words.length; i++) {
            if (!words[i].isEmpty()) {
                char firstChar = words[i].charAt(0);
                System.out.println("Các chữ cái đầu của mỗi từ là: " + firstChar);
            }
        }
    }
}
