import java.util.Scanner;

public class BaiTap04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập chuỗi: ");
        String str = sc.nextLine();

        String[] words = str.split(" ");

        System.out.println("Số từ trong chuỗi là: " + words.length);
        }
    }
